import java.util.Scanner;

public class Task_4_Delivery {
    public static void main(String[] args) {
        int N, route = 1;
        Scanner in = new Scanner(System.in);
        System.out.println("Вкажіть кількість клієнтів: ");
        N = in.nextInt();
        do {
            route *= N--;
        } while (N > 0);
        System.out.print(route+" можливих варіантів доставлення товару");
    }
}
