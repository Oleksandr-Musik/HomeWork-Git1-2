public class Task_3_Printing_Shapes {
    public static void main(String[] args) {
        System.out.println("Прямокутник\n");
        for (int i = 0; i < 10; i++) {

            for (int j = 0; j < 10; j++) {
                System.out.print("*");
            }
                System.out.println();
        }

        System.out.println("\nПрямокутний трикутник\n");
        for (int i = 0; i < 10; i++) {

            for (int j = -1; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println("\nРівносторонній трикутник");
        for (int i = 0; i < 9; i++) {

            for (int j = 0; j < 9; j++) {
                if (i + j >= 9 - 1&& i >= j)
                System.out.print("*");
                else
                    System.out.print(" ");
                }
            System.out.println();
        }

        System.out.println("\nРомб");
        for (int i = 0; i < 9; i++) {

            for (int j = 0; j < 9; j++) {
                if (i + j >= 9 - 1&& i >= j)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
        for (int i = 0; i < 9; i++) {

            for (int j = 0; j < 9; j++) {
                if (i + j <= 9 - 1&& j >= i)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
    }
}
