public class Task_2_SumMin {
    public static void main(String[] args) {
        int A = 1, B = 20;
        while (A < B) {
            A++;
            System.out.println(A);
            if (A == 19)
            break;
        }
        System.out.println("\nНепарні значення\n");
        int a = 1, b = 20;
        while (a < b) {
            a++;
            if ((a % 2) == 0)
            {
                continue;
            }else
            System.out.println(a);
        }
    }
}
